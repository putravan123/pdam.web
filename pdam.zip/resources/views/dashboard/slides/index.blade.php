@extends('dashboard.app')

@section('content')
    <div class="container">
        <h1>Daftar Slide</h1>
        <a href="{{ route('slides.create') }}" class="btn btn-primary">Buat Slide Baru</a>
        <br><br>
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($slides as $slide)
                    <tr>
                        <td>{{ $slide->title }}</td>
                        <td>
                            <img src="{{ asset('storage/' . $slide->image) }}" style="width: 100px; height: 100px; object-fit: cover;" alt="{{ $slide->title }}">
                        </td>                        
                        <td>
                            <a href="{{ route('slides.edit', $slide->id) }}" class="btn btn-warning">Edit</a>
                            <form action="{{ route('slides.destroy', $slide->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus slide ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
