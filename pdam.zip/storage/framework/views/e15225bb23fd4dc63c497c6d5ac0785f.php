

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Abouts</h1>
        <a href="<?php echo e(route('abouts.create')); ?>" class="btn btn-primary">Create New About</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Icon</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $abouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($about->title); ?></td>
                        <td><?php echo e($about->description); ?></td>
                        <td>
                            <?php if($about->icon): ?>
                                <img src="<?php echo e(asset('storage/' . $about->icon)); ?>" alt="<?php echo e($about->title); ?> icon"
                                    style="width: 40px; height: 40px;">
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('abouts.edit', $about)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('abouts.destroy', $about)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file-laravel\New_laravel\webpdam\resources\views/dashboard/abouts/index.blade.php ENDPATH**/ ?>