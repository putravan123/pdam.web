

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Daftar Slide</h1>
        <a href="<?php echo e(route('slides.create')); ?>" class="btn btn-primary">Buat Slide Baru</a>
        <br><br>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($slide->title); ?></td>
                        <td>
                            <img src="<?php echo e(asset('storage/' . $slide->image)); ?>" style="width: 100px; height: 100px; object-fit: cover;" alt="<?php echo e($slide->title); ?>">
                        </td>                        
                        <td>
                            <a href="<?php echo e(route('slides.edit', $slide->id)); ?>" class="btn btn-warning">Edit</a>
                            <form action="<?php echo e(route('slides.destroy', $slide->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus slide ini?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file-laravel\New_laravel\webpdam\resources\views/dashboard/slides/index.blade.php ENDPATH**/ ?>